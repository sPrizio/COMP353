Report.pdf is the written report. 
If needed a .tex of the report is included.