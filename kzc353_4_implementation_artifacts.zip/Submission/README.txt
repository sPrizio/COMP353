Inside this .zip you will find everything you need to run the code.

	Data.xlsx
		This file is a visual representation of the data contained within the database. It organizes the students into teams and associates demo dates with students visually in order to adequately gauge the accuracy of the query results.
		
	queries.sql
		This file contains the implementations in SQL of the 9 questions outlined in the project description
		
	schema.sql
		This file is the database itself. It can be imported locally into MySQL Workbench if you cannot connect to our web-based database interface located at https://kzc353.encs.concordia.ca/index.php.
		
	index.php
		This file is the user interface for accessing the database via queries. The queries can be entered via the textbox and the results will be printed underneath. This page can be accessed at: https://kzc353.encs.concordia.ca/index.php.